"use client";
import React from "react";
import Image from "next/image";
import { X, Check, Star } from "./lucide-react";
import { useHotel } from "../context/HotelContext";

export default function RoomDetailsModal() {
  const { activeModalRoom, closeRoomDetails, openBookingModal } = useHotel();

  if (!activeModalRoom) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-gray-100 flex flex-col">
        {/* Header Image */}
        <div className="relative h-64 sm:h-80 w-full shrink-0">
          <Image
            src={activeModalRoom.imageUrl}
            alt={activeModalRoom.name}
            fill
            className="object-cover rounded-t-2xl"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
          
          {/* Close button */}
          <button
            onClick={closeRoomDetails}
            className="absolute top-4 right-4 p-2 text-white bg-black/40 hover:bg-black/70 rounded-full backdrop-blur-md transition-colors"
          >
            <X size={20} />
          </button>

          {/* Room info on image */}
          <div className="absolute bottom-4 left-6 right-6 flex flex-wrap justify-between items-end gap-2 text-white">
            <div>
              <span className="px-3 py-1 bg-amber-500 text-slate-950 font-bold text-xs uppercase rounded-full">
                {activeModalRoom.type} Room
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold mt-1 text-white">
                {activeModalRoom.name}
              </h2>
            </div>
            <div className="text-right">
              <span className="text-3xl font-black text-amber-400">
                ${activeModalRoom.price}
              </span>
              <span className="text-sm text-gray-200"> / night</span>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Quick Specifications */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-amber-50/60 border border-amber-200/60 rounded-xl text-center">
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase">Guests</p>
              <p className="text-lg font-bold text-gray-900">Up to {activeModalRoom.capacity}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase">Bedrooms</p>
              <p className="text-lg font-bold text-gray-900">{activeModalRoom.bedCount} Bed(s)</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase">Bathrooms</p>
              <p className="text-lg font-bold text-gray-900">{activeModalRoom.bathCount} Bath</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 font-medium uppercase">Room Size</p>
              <p className="text-lg font-bold text-gray-900">{activeModalRoom.size || "45 m²"}</p>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Room Overview</h3>
            <p className="text-gray-600 leading-relaxed text-sm sm:text-base">
              {activeModalRoom.description}
            </p>
          </div>

          {/* Amenities Grid */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3">Included Amenities</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {activeModalRoom.amenities.map((amenity, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                  <div className="p-1 rounded-full bg-emerald-100 text-emerald-600">
                    <Check size={14} />
                  </div>
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-1.5 text-amber-500 font-semibold text-sm">
              <Star size={18} className="fill-amber-400 text-amber-400" />
              <span>5.0 Rating</span>
              <span className="text-gray-400 font-normal">({activeModalRoom.reviewsCount || 100}+ reviews)</span>
            </div>

            <div className="flex gap-3 w-full sm:w-auto">
              <button
                onClick={closeRoomDetails}
                className="flex-1 sm:flex-none px-5 py-2.5 border border-gray-300 rounded-xl font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  closeRoomDetails();
                  openBookingModal(activeModalRoom);
                }}
                className="flex-1 sm:flex-none px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02]"
              >
                Book This Room
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
