"use client";
import React, { useState } from "react";
import Image from "next/image";
import { X, Calendar } from "./lucide-react";
import { useHotel } from "../context/HotelContext";

export default function BookingModal() {
  const { isBookingOpen, bookingTargetRoom, closeBookingModal, createBooking } = useHotel();

  const [form, setForm] = useState({
    name: "Natan Muleta",
    email: "natan@example.com",
    phone: "+1 (555) 234-5678",
    checkIn: "2026-11-10",
    checkOut: "2026-11-14",
    guests: 2,
    specialRequests: "",
  });

  if (!isBookingOpen || !bookingTargetRoom) return null;

  // Calculate nights
  const start = new Date(form.checkIn);
  const end = new Date(form.checkOut);
  const diffTime = Math.max(0, end - start);
  const nights = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1);
  const subtotal = nights * bookingTargetRoom.price;
  const taxes = Math.round(subtotal * 0.12);
  const grandTotal = subtotal + taxes;

  const handleSubmit = (e) => {
    e.preventDefault();
    createBooking({
      ...form,
      nights,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center border-b border-amber-500/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden relative shrink-0">
              <Image
                src={bookingTargetRoom.imageUrl}
                alt={bookingTargetRoom.name}
                fill
                className="object-cover"
              />
            </div>
            <div>
              <p className="text-xs text-amber-400 font-semibold uppercase tracking-wider">Reservation</p>
              <h3 className="text-base sm:text-lg font-bold text-white line-clamp-1">{bookingTargetRoom.name}</h3>
            </div>
          </div>
          <button
            onClick={closeBookingModal}
            className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Dates & Guests */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Check-In</label>
              <input
                type="date"
                required
                value={form.checkIn}
                onChange={(e) => setForm({ ...form, checkIn: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Check-Out</label>
              <input
                type="date"
                required
                value={form.checkOut}
                onChange={(e) => setForm({ ...form, checkOut: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Guests</label>
              <select
                value={form.guests}
                onChange={(e) => setForm({ ...form, guests: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
              >
                {Array.from({ length: bookingTargetRoom.capacity || 4 }).map((_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {i + 1} Guest{i > 0 ? "s" : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Guest Personal Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Full Name</label>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="John Doe"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Email Address</label>
              <input
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="john@example.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Phone Number</label>
            <input
              type="tel"
              required
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="+1 (555) 000-0000"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 uppercase mb-1">Special Requests (Optional)</label>
            <textarea
              rows={2}
              value={form.specialRequests}
              onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
              placeholder="E.g. High floor, airport pickup, late arrival..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
            ></textarea>
          </div>

          {/* Pricing Breakdown Summary */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <div className="flex justify-between text-xs text-gray-600">
              <span>${bookingTargetRoom.price} x {nights} night{nights > 1 ? "s" : ""}</span>
              <span>${subtotal}</span>
            </div>
            <div className="flex justify-between text-xs text-gray-600">
              <span>Taxes & Resort Fees (12%)</span>
              <span>${taxes}</span>
            </div>
            <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-bold text-gray-900">
              <span>Estimated Total</span>
              <span className="text-xl text-amber-600 font-black">${grandTotal}</span>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={closeBookingModal}
              className="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20 text-sm transition-all"
            >
              Confirm Booking (Mock)
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
