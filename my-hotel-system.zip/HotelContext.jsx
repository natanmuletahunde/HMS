"use client";
import React, { createContext, useContext, useState, useEffect } from "react";
import { mockRooms, hotelInfo } from "../data/mockData";
import { useToast } from "../Components/toast";

const HotelContext = createContext(null);

export const useHotel = () => {
  const context = useContext(HotelContext);
  if (!context) throw new Error("useHotel must be used within HotelProvider");
  return context;
};

export function HotelProvider({ children }) {
  const toast = useToast();
  const [rooms, setRooms] = useState(mockRooms);
  const [filterType, setFilterType] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Search Bar State
  const [checkInDate, setCheckInDate] = useState("");
  const [checkOutDate, setCheckOutDate] = useState("");
  const [guestCount, setGuestCount] = useState(2);
  const [roomTypeFilter, setRoomTypeFilter] = useState("ALL");

  // Modal states
  const [activeModalRoom, setActiveModalRoom] = useState(null);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingTargetRoom, setBookingTargetRoom] = useState(null);
  const [confirmedBooking, setConfirmedBooking] = useState(null);

  // User bookings list (in-memory mock store)
  const [bookings, setBookings] = useState([
    {
      id: "BK-8092",
      room: mockRooms[0],
      guestName: "Natan Muleta",
      guestEmail: "natan@example.com",
      guestPhone: "+1 (555) 019-2834",
      checkIn: "2026-11-05",
      checkOut: "2026-11-08",
      nights: 3,
      guests: 2,
      totalPrice: 540,
      status: "Confirmed",
      createdAt: "2026-10-27",
    },
  ]);

  // Open Room Details modal
  const openRoomDetails = (room) => {
    setActiveModalRoom(room);
  };

  const closeRoomDetails = () => {
    setActiveModalRoom(null);
  };

  // Open Booking Modal
  const openBookingModal = (room) => {
    setBookingTargetRoom(room);
    setIsBookingOpen(true);
  };

  const closeBookingModal = () => {
    setIsBookingOpen(false);
    setBookingTargetRoom(null);
  };

  // Submit new booking
  const createBooking = (bookingData) => {
    const nights = Math.max(1, bookingData.nights || 1);
    const totalPrice = nights * bookingTargetRoom.price;
    const newBooking = {
      id: `BK-${Math.floor(1000 + Math.random() * 9000)}`,
      room: bookingTargetRoom,
      guestName: bookingData.name,
      guestEmail: bookingData.email,
      guestPhone: bookingData.phone,
      checkIn: bookingData.checkIn,
      checkOut: bookingData.checkOut,
      specialRequests: bookingData.specialRequests || "None",
      nights,
      guests: bookingData.guests || 2,
      totalPrice,
      status: "Confirmed",
      createdAt: new Date().toISOString().split("T")[0],
    };

    setBookings((prev) => [newBooking, ...prev]);
    setConfirmedBooking(newBooking);
    setIsBookingOpen(false);
    toast.success(`Reservation Confirmed! Reference: ${newBooking.id}`);
  };

  // Cancel booking
  const cancelBooking = (id) => {
    setBookings((prev) => prev.filter((b) => b.id !== id));
    toast.info(`Reservation ${id} was cancelled.`);
  };

  // Filtered rooms logic
  const filteredRooms = rooms.filter((room) => {
    const matchesType = filterType === "ALL" || room.type.toLowerCase() === filterType.toLowerCase();
    const matchesSearch =
      searchQuery === "" ||
      room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      room.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <HotelContext.Provider
      value={{
        hotelInfo,
        rooms,
        filteredRooms,
        filterType,
        setFilterType,
        searchQuery,
        setSearchQuery,
        checkInDate,
        setCheckInDate,
        checkOutDate,
        setCheckOutDate,
        guestCount,
        setGuestCount,
        roomTypeFilter,
        setRoomTypeFilter,
        activeModalRoom,
        openRoomDetails,
        closeRoomDetails,
        isBookingOpen,
        bookingTargetRoom,
        openBookingModal,
        closeBookingModal,
        createBooking,
        confirmedBooking,
        setConfirmedBooking,
        bookings,
        cancelBooking,
      }}
    >
      {children}
    </HotelContext.Provider>
  );
}
