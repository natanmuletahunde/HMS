"use client";
import React from "react";
import Image from "next/image";
import { Award, Shield, Check } from "../Components/lucide-react";
import { useHotel } from "../context/HotelContext";

export default function About() {
  const { hotelInfo } = useHotel();

  return (
    <section id="about" className="py-20 bg-white relative overflow-hidden">
      {/* Background soft ambient accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-100/40 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-100/30 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column: Image with floating badges */}
          <div className="relative group">
            <div className="relative h-[340px] sm:h-[440px] w-full rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
              <Image
                src="/about-1.jpg"
                alt="Luxury Hotel Exterior"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent"></div>
            </div>

            {/* Floating 5-Star Luxury Badge */}
            <div className="absolute -bottom-6 -left-2 sm:left-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-amber-200/60 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 shadow-md">
                <Award size={26} />
              </div>
              <div>
                <p className="text-xs uppercase font-extrabold tracking-wider text-amber-600">Certified</p>
                <p className="text-base font-black text-slate-900">5-Star Luxury Standard</p>
              </div>
            </div>

            {/* Small secondary badge */}
            <div className="hidden sm:flex absolute -top-4 -right-4 bg-slate-900 text-white p-3.5 rounded-2xl shadow-lg border border-slate-700 items-center gap-2.5">
              <Shield size={20} className="text-amber-400" />
              <div className="text-xs font-bold">
                <p>Private & Secure</p>
                <p className="text-[10px] text-gray-400 font-normal">24/7 Monitored Grounds</p>
              </div>
            </div>
          </div>

          {/* Right Column: Story & Features */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100/70 border border-amber-300 text-amber-800 text-xs font-bold uppercase tracking-widest">
              About Our Heritage
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
              A Symphony of <br />
              <span className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 bg-clip-text text-transparent">
                Luxury, Comfort & Calm
              </span>
            </h2>

            <p className="text-gray-600 text-sm sm:text-base leading-relaxed">
              At {hotelInfo.shortName}, we transcend the conventional hospitality experience. Surrounded by panoramic coastal beauty, each suite and common space has been meticulously designed to cultivate peace, productivity, and indulgence.
            </p>

            {/* Core Pillars */}
            <div className="space-y-3 pt-2">
              {[
                "Personalized 24/7 concierge & round-the-clock room dining",
                "Eco-conscious luxury architecture with climate-controlled suites",
                "World-class private spa, infinity pool & culinary hotspots",
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 text-sm font-semibold text-slate-800">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                    <Check size={14} />
                  </div>
                  <span>{item}</span>
                </div>
              ))}
            </div>

            {/* Numerical Stats Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-gray-100">
              {hotelInfo.stats.map((stat, i) => (
                <div key={i} className="p-3 bg-slate-50 rounded-xl text-center border border-gray-100">
                  <p className="text-2xl font-black text-amber-500">{stat.value}</p>
                  <p className="text-[11px] font-bold text-gray-500 uppercase mt-0.5">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
