# Grand Horizon - Hotel Management System 🏨

A modern, high-performance Hotel Management System landing & reservation web application built with **Next.js**, **React 19**, and **Tailwind CSS**.

---

## ✨ Features & Capabilities

- 🌟 **5-Star Luxury Landing Page**: Dynamic 3-slide hero carousel with smooth transitions, badges, and quick-reservation search bar.
- 🛏️ **Room Catalog & Interactive Filtering**: Filter accommodations by category (*All*, *Single Deluxe*, *Double Executive*, *Extended Stay*) with live search.
- 🔍 **Room Details Modal**: In-depth view featuring room size, capacity, bed & bath counts, photo gallery, and complete amenities checklist.
- 📅 **Mock Booking & Reservation Flow**: Live night & tax pricing calculator, guest details capture, instant mock confirmation, and reference code generation.
- 🧾 **Digital Booking Receipt**: Real-time receipt popup with reference number, room details, and stay dates.
- 📋 **Active Reservations Drawer**: View, inspect, and cancel active mock reservations on the fly.
- 🛎️ **World-Class Services Showcase**: Interactive cards featuring Dining, Spa, Fitness, Sports, Events, and Accommodations.
- 💬 **Verified Guest Testimonials**: Authentic guest reviews with ratings and profile cards.
- ✉️ **Concierge Contact Form**: Responsive inquiry submission with interactive toast feedback.
- 🔔 **Toast Notification Engine**: Animated real-time notifications for bookings, inquiries, and cancellations.

---

## 🏗️ Project Architecture

```
my-hotel-system/
├── app/
│   ├── Components/
│   │   ├── ActiveBookingsModal.jsx  # Active reservations manager drawer
│   │   ├── BookingModal.jsx         # Booking form with price calculation
│   │   ├── BookingReceiptModal.jsx  # Post-reservation receipt
│   │   ├── RoomDetailsModal.jsx     # Detailed room view & amenities
│   │   ├── lucide-react.jsx         # Lightweight SVG icon collection
│   │   └── toast.jsx                # Toast notifications provider & hook
│   ├── context/
│   │   └── HotelContext.jsx         # Centralized state (rooms, filters, bookings)
│   ├── data/
│   │   └── mockData.js              # Decoupled mock data layer
│   ├── Pages/
│   │   ├── Header.jsx               # Navigation bar with reservation counter
│   │   ├── Hero.jsx                 # Auto-rotating carousel & quick search
│   │   ├── Rooms.jsx                # Filterable catalog of suites & rooms
│   │   ├── About.jsx                # Storytelling, badges & statistics
│   │   ├── Servise.jsx              # Grid of hotel services & amenities
│   │   ├── Testimonials.jsx         # Guest reviews & ratings
│   │   ├── Contact.jsx              # Contact details & inquiry form
│   │   └── Footer.jsx               # Footer links & newsletter signup
│   ├── globals.css                  # Tailwind imports, brand variables & animations
│   ├── layout.js                    # Root layout with fonts & context providers
│   └── page.js                      # Main landing page
├── public/                          # Images, room photos, logos, and icons
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── next.config.mjs
```

---

## 🚀 Getting Started

### 1. Install Dependencies

```bash
cd c:\Users\PC\Desktop\project\my-hotel-system
npm install
```

### 2. Start the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to experience the application.

---

## 🔌 Connecting to Your Custom Backend Logic

This project is decoupled from third-party hardcoded endpoints. When you are ready to connect your database or API:

1. **Rooms**: Update `app/context/HotelContext.jsx` inside the `useEffect` to fetch rooms from your own API endpoint (`/api/rooms` or external backend).
2. **Reservations**: In `createBooking` (`HotelContext.jsx`), replace the local state update with an HTTP `POST` request to your bookings table.
3. **Authentication**: Plug in NextAuth, Supabase, Firebase, or JWT auth inside `HotelContext.jsx`.

---

## 📄 License

Private & Custom Project for Hotel Management.
