"use client";
import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Menu, X, Calendar } from "../Components/lucide-react";
import { useHotel } from "../context/HotelContext";
import ActiveBookingsModal from "../Components/ActiveBookingsModal";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isBookingsModalOpen, setIsBookingsModalOpen] = useState(false);
  const { hotelInfo, bookings } = useHotel();

  return (
    <>
      <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-amber-500/20 text-white transition-all shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            {/* Logo & Brand */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative w-11 h-11 flex items-center justify-center">
                <Image
                  src="/Images/logowb.png"
                  alt="Hotel Logo"
                  width={44}
                  height={44}
                  className="object-contain group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div>
                <span className="text-xl sm:text-2xl font-black bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500 bg-clip-text text-transparent">
                  {hotelInfo.shortName}
                </span>
                <span className="block text-[10px] tracking-widest text-amber-300/80 uppercase font-medium">
                  Luxury Resort & Suites
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8 text-sm font-semibold tracking-wide">
              {[
                { label: "Home", href: "#home" },
                { label: "Rooms", href: "#rooms" },
                { label: "About", href: "#about" },
                { label: "Services", href: "#services" },
                { label: "Reviews", href: "#reviews" },
                { label: "Contact", href: "#contact" },
              ].map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-gray-300 hover:text-amber-400 transition-colors uppercase text-xs"
                >
                  {item.label}
                </a>
              ))}
            </nav>

            {/* Actions */}
            <div className="hidden sm:flex items-center gap-3">
              {/* My Reservations pill */}
              <button
                onClick={() => setIsBookingsModalOpen(true)}
                className="relative px-3.5 py-2 text-xs font-semibold text-gray-200 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-full transition-all flex items-center gap-2"
              >
                <Calendar size={14} className="text-amber-400" />
                <span>My Bookings</span>
                {bookings.length > 0 && (
                  <span className="w-5 h-5 flex items-center justify-center text-[10px] font-bold bg-amber-500 text-slate-950 rounded-full">
                    {bookings.length}
                  </span>
                )}
              </button>

              <a
                href="#rooms"
                className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-extrabold text-xs uppercase tracking-wider rounded-full shadow-lg shadow-amber-500/20 hover:scale-105 transition-all"
              >
                Reserve Now
              </a>
            </div>

            {/* Mobile Hamburger */}
            <div className="md:hidden flex items-center gap-2">
              <button
                onClick={() => setIsBookingsModalOpen(true)}
                className="p-2 text-amber-400 bg-slate-800 rounded-lg relative"
              >
                <Calendar size={20} />
                {bookings.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 flex items-center justify-center text-[9px] font-bold bg-amber-500 text-slate-950 rounded-full">
                    {bookings.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-gray-300 hover:text-white bg-slate-800 rounded-lg transition-colors"
              >
                {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-slate-950/95 border-b border-amber-500/20 px-6 py-6 space-y-4">
            {[
              { label: "Home", href: "#home" },
              { label: "Rooms & Suites", href: "#rooms" },
              { label: "About Hotel", href: "#about" },
              { label: "Our Services", href: "#services" },
              { label: "Guest Reviews", href: "#reviews" },
              { label: "Contact Us", href: "#contact" },
            ].map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block text-sm font-semibold text-gray-300 hover:text-amber-400 py-1 transition-colors uppercase tracking-wider"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-4 border-t border-slate-800 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsBookingsModalOpen(true);
                }}
                className="w-full py-2.5 bg-slate-800 text-amber-400 font-bold rounded-xl text-xs uppercase"
              >
                My Reservations ({bookings.length})
              </button>
              <a
                href="#rooms"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 bg-amber-500 text-slate-950 text-center font-bold rounded-xl text-xs uppercase"
              >
                Book A Room
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Active Bookings Modal */}
      <ActiveBookingsModal
        isOpen={isBookingsModalOpen}
        onClose={() => setIsBookingsModalOpen(false)}
      />
    </>
  );
}
