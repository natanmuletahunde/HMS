import Header from "./Pages/Header";
import Hero from "./Pages/Hero";
import Rooms from "./Pages/Rooms";
import About from "./Pages/About";
import Servise from "./Pages/Servise";
import Testimonials from "./Pages/Testimonials";
import Contact from "./Pages/Contact";
import Footer from "./Pages/Footer";

export default function Page() {
  return (
    <main className="min-h-screen flex flex-col bg-slate-50">
      <Header />
      <Hero />
      <Rooms />
      <About />
      <Servise />
      <Testimonials />
      <Contact />
      <Footer />
    </main>
  );
}
