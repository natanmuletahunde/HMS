import { Inter } from 'next/font/google';
import './globals.css';
import { ToastProvider } from './Components/toast';
import { HotelProvider } from './context/HotelContext';
import RoomDetailsModal from './Components/RoomDetailsModal';
import BookingModal from './Components/BookingModal';
import BookingReceiptModal from './Components/BookingReceiptModal';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Grand Horizon | Luxury Hotel & Resort Management',
  description: 'Premium Hotel Management System. Seamless room reservations, luxury suites, 5-star hospitality, and world-class resort amenities.',
  icons: {
    icon: '/Images/logo.png',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.className} min-h-screen bg-slate-50 text-slate-900 antialiased selection:bg-amber-400 selection:text-slate-950`}>
        <ToastProvider>
          <HotelProvider>
            {children}
            {/* Global Interactive Modals */}
            <RoomDetailsModal />
            <BookingModal />
            <BookingReceiptModal />
          </HotelProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
