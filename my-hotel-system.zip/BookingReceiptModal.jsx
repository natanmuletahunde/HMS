"use client";
import React from "react";
import Image from "next/image";
import { X, Check } from "./lucide-react";
import { useHotel } from "../context/HotelContext";

export default function BookingReceiptModal() {
  const { confirmedBooking, setConfirmedBooking, hotelInfo } = useHotel();

  if (!confirmedBooking) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden text-gray-900">
        {/* Top Header Banner */}
        <div className="p-6 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-center relative">
          <button
            onClick={() => setConfirmedBooking(null)}
            className="absolute top-4 right-4 p-1 text-slate-900/70 hover:text-slate-950 rounded-full hover:bg-black/10 transition-colors"
          >
            <X size={20} />
          </button>
          <div className="w-14 h-14 bg-white/90 rounded-full mx-auto flex items-center justify-center shadow-lg mb-2">
            <Check size={28} className="text-emerald-600" />
          </div>
          <h3 className="text-xl font-black">Booking Confirmed!</h3>
          <p className="text-xs font-semibold text-slate-900/80 mt-0.5">
            Reservation Ref: <span className="font-mono bg-white/40 px-2 py-0.5 rounded">{confirmedBooking.id}</span>
          </p>
        </div>

        {/* Receipt Content */}
        <div className="p-6 space-y-4 text-sm">
          <div className="text-center pb-3 border-b border-gray-100">
            <h4 className="font-bold text-base text-gray-900">{hotelInfo.name}</h4>
            <p className="text-xs text-gray-500">{hotelInfo.address}</p>
          </div>

          <div className="grid grid-cols-2 gap-3 py-2 bg-slate-50 p-3 rounded-xl text-xs">
            <div>
              <p className="text-gray-500 font-medium">Guest Name</p>
              <p className="font-bold text-gray-900">{confirmedBooking.guestName}</p>
            </div>
            <div>
              <p className="text-gray-500 font-medium">Guest Email</p>
              <p className="font-bold text-gray-900 truncate">{confirmedBooking.guestEmail}</p>
            </div>
            <div>
              <p className="text-gray-500 font-medium">Check-In</p>
              <p className="font-bold text-gray-900">{confirmedBooking.checkIn}</p>
            </div>
            <div>
              <p className="text-gray-500 font-medium">Check-Out</p>
              <p className="font-bold text-gray-900">{confirmedBooking.checkOut}</p>
            </div>
          </div>

          <div className="space-y-1.5 pt-1 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-600">Reserved Room:</span>
              <span className="font-semibold text-gray-900">{confirmedBooking.room.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duration:</span>
              <span className="font-semibold text-gray-900">{confirmedBooking.nights} night(s)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Guests:</span>
              <span className="font-semibold text-gray-900">{confirmedBooking.guests} Person(s)</span>
            </div>
            <div className="pt-2 border-t border-dashed border-gray-200 flex justify-between items-center text-sm font-bold">
              <span className="text-gray-900">Total Price:</span>
              <span className="text-lg text-emerald-600 font-black">${confirmedBooking.totalPrice}</span>
            </div>
          </div>

          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
            <Check size={16} className="text-emerald-600 shrink-0" />
            <span>A confirmation has been saved to your local mock active reservations.</span>
          </div>

          {/* Action button */}
          <div className="pt-2">
            <button
              onClick={() => setConfirmedBooking(null)}
              className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-sm transition-colors"
            >
              Done & Return to Site
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
