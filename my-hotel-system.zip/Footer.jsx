"use client";
import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useHotel } from "../context/HotelContext";
import { useToast } from "../Components/toast";

export default function Footer() {
  const { hotelInfo } = useHotel();
  const toast = useToast();
  const [newsletterEmail, setNewsletterEmail] = useState("");

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (newsletterEmail) {
      toast.success("Subscribed! You will receive our seasonal offers and private invites.");
      setNewsletterEmail("");
    }
  };

  return (
    <footer className="relative bg-slate-950 text-gray-400 pt-16 pb-10 border-t-4 border-amber-500 overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-amber-500/10 blur-[130px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-1 space-y-4">
            <Link href="/" className="flex items-center gap-3 w-max">
              <div className="relative w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
                <Image
                  src="/Images/logo.png"
                  alt="Hotel Logo"
                  width={40}
                  height={40}
                  className="object-contain"
                />
              </div>
              <span className="text-2xl font-black text-white tracking-tight">
                {hotelInfo.shortName}
              </span>
            </Link>
            
            <p className="text-xs leading-relaxed text-gray-400 pr-2">
              {hotelInfo.description}
            </p>

            {/* Newsletter */}
            <form onSubmit={handleNewsletter} className="pt-2">
              <p className="text-xs font-bold text-white uppercase tracking-wider mb-1.5">VIP Newsletter</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email..."
                  className="px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-amber-400 w-full"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors shrink-0"
                >
                  Join
                </button>
              </div>
            </form>
          </div>

          {/* Hotel Experience */}
          <div>
            <h3 className="text-white font-bold tracking-wider mb-4 uppercase text-xs">
              Resort Experience
            </h3>
            <ul className="space-y-2.5 text-xs">
              {[
                "Rooms & Deluxe Suites",
                "Fine Dining & Wine Bar",
                "Holistic Spa & Treatments",
                "Infinity Pool & Cabanas",
                "Private Wedding Pavilion",
                "Executive Conference Salons",
              ].map((item) => (
                <li key={item}>
                  <a href="#services" className="hover:text-amber-400 transition-colors inline-block">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold tracking-wider mb-4 uppercase text-xs">
              Navigation
            </h3>
            <ul className="space-y-2.5 text-xs">
              {[
                { name: "Home Showcase", href: "#home" },
                { name: "Explore Rooms", href: "#rooms" },
                { name: "About Hotel", href: "#about" },
                { name: "Guest Amenities", href: "#services" },
                { name: "Verified Reviews", href: "#reviews" },
                { name: "Contact Concierge", href: "#contact" },
              ].map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="hover:text-amber-400 transition-colors inline-block">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-white font-bold tracking-wider mb-4 uppercase text-xs">
              Direct Contact
            </h3>
            <ul className="space-y-3 text-xs text-gray-400">
              <li className="leading-snug">
                <span className="block text-gray-300 font-semibold">Address</span>
                {hotelInfo.address}
              </li>
              <li>
                <span className="block text-gray-300 font-semibold">Phone</span>
                {hotelInfo.phone}
              </li>
              <li>
                <span className="block text-gray-300 font-semibold">Concierge Email</span>
                {hotelInfo.email}
              </li>
              <li>
                <span className="block text-gray-300 font-semibold">Check-In / Check-Out</span>
                {hotelInfo.checkInTime} / {hotelInfo.checkOutTime}
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p>© {new Date().getFullYear()} {hotelInfo.name}. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Terms of Hospitality</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Cookie Preferences</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
