"use client";
import React from "react";
import Image from "next/image";
import { X, Calendar } from "./lucide-react";
import { useHotel } from "../context/HotelContext";

export default function ActiveBookingsModal({ isOpen, onClose }) {
  const { bookings, cancelBooking } = useHotel();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center border-b border-amber-500/30">
          <div>
            <h3 className="text-lg font-bold text-white">Active Reservations</h3>
            <p className="text-xs text-amber-400">Manage your mock bookings in real-time</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-4">
          {bookings.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Calendar size={48} className="mx-auto mb-3 text-gray-300" />
              <p className="font-medium text-base">No active reservations found.</p>
              <p className="text-xs text-gray-400 mt-1">Book any room from the catalog to see it appear here.</p>
            </div>
          ) : (
            bookings.map((booking) => (
              <div
                key={booking.id}
                className="p-4 border border-gray-200 rounded-xl hover:border-amber-300 transition-all flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between bg-slate-50/50"
              >
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg overflow-hidden relative shrink-0">
                    <Image
                      src={booking.room.imageUrl}
                      alt={booking.room.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                        {booking.id}
                      </span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {booking.status}
                      </span>
                    </div>
                    <h4 className="font-bold text-gray-900 text-sm mt-1">{booking.room.name}</h4>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {booking.checkIn} to {booking.checkOut} ({booking.nights} night{booking.nights > 1 ? "s" : ""})
                    </p>
                  </div>
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2">
                  <span className="text-lg font-black text-amber-600">${booking.totalPrice}</span>
                  <button
                    onClick={() => cancelBooking(booking.id)}
                    className="px-3 py-1 text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors"
                  >
                    Cancel Booking
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-gray-50 border-t border-gray-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
