"use client";
import React from "react";
import Image from "next/image";
import { Star, Search } from "../Components/lucide-react";
import { useHotel } from "../context/HotelContext";

export default function Rooms() {
  const {
    filteredRooms,
    filterType,
    setFilterType,
    searchQuery,
    setSearchQuery,
    openRoomDetails,
    openBookingModal,
  } = useHotel();

  const categories = [
    { label: "All Rooms", value: "ALL" },
    { label: "Single Deluxe", value: "Single" },
    { label: "Double Executive", value: "Double" },
    { label: "Extended Stay", value: "Extended" },
  ];

  return (
    <section id="rooms" className="py-20 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-800 text-xs font-bold uppercase tracking-widest mb-3">
            Handcrafted Accommodations
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Explore Our Luxury <span className="text-amber-500">Rooms & Suites</span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-600">
            Every room offers curated comforts, bespoke bedding, and panoramic views designed for your optimal rest.
          </p>
        </div>

        {/* Filter Tabs and Search Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-10 pb-6 border-b border-gray-200">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setFilterType(cat.value)}
                className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-xl transition-all ${
                  filterType.toLowerCase() === cat.value.toLowerCase()
                    ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 scale-105"
                    : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Quick search input */}
          <div className="relative w-full md:w-72">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name or feature..."
              className="w-full pl-9 pr-4 py-2 bg-white border border-gray-300 rounded-xl text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <Search size={15} className="absolute left-3 top-2.5 text-gray-400" />
          </div>
        </div>

        {/* Rooms Grid */}
        {filteredRooms.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-gray-200">
            <p className="text-base font-bold text-gray-800">No rooms match your filter.</p>
            <p className="text-xs text-gray-500 mt-1">Try resetting the category filter or search query.</p>
            <button
              onClick={() => {
                setFilterType("ALL");
                setSearchQuery("");
              }}
              className="mt-4 px-4 py-2 bg-amber-500 text-slate-950 text-xs font-bold rounded-xl"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRooms.map((room) => (
              <div
                key={room.id}
                className="group bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col hover:-translate-y-1.5"
              >
                {/* Image & Price */}
                <div className="relative h-56 w-full overflow-hidden bg-slate-900">
                  <Image
                    src={room.imageUrl}
                    alt={room.name}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                  
                  {/* Category Pill */}
                  <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-md text-amber-300 text-[11px] font-bold uppercase rounded-lg">
                    {room.type}
                  </span>

                  {/* Price Tag */}
                  <span className="absolute bottom-3 left-3 px-3 py-1 bg-amber-500 text-slate-950 font-black text-sm rounded-lg shadow-md">
                    ${room.price} <span className="text-[10px] font-bold text-slate-900/80">/ NIGHT</span>
                  </span>
                </div>

                {/* Card Body */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <h3 className="text-base font-bold text-slate-900 line-clamp-1 group-hover:text-amber-600 transition-colors">
                        {room.name}
                      </h3>
                      <div className="flex gap-0.5 text-amber-400 shrink-0">
                        {Array.from({ length: room.rating }).map((_, i) => (
                          <Star key={i} size={14} className="fill-amber-400" />
                        ))}
                      </div>
                    </div>

                    <p className="text-xs text-gray-500 line-clamp-2 leading-relaxed">
                      {room.description}
                    </p>
                  </div>

                  {/* Room Features Icons */}
                  <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-600">
                    <div className="flex items-center gap-1.5">
                      <Image src="/sleeping.png" alt="Bed" width={16} height={16} className="object-contain" />
                      <span>{room.bedCount} Bed{room.bedCount > 1 ? "s" : ""}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Image src="/bathtub.png" alt="Bath" width={16} height={16} className="object-contain" />
                      <span>{room.bathCount} Bath</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Image src="/wifi.png" alt="Wifi" width={16} height={16} className="object-contain" />
                      <span>Free Wifi</span>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="pt-2 grid grid-cols-2 gap-2.5">
                    <button
                      onClick={() => openRoomDetails(room)}
                      className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-xs rounded-xl transition-colors"
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => openBookingModal(room)}
                      className="w-full py-2 bg-slate-900 hover:bg-amber-500 hover:text-slate-950 text-white font-bold text-xs rounded-xl transition-all shadow-md"
                    >
                      Book Room
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
