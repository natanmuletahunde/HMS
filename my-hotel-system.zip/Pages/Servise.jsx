"use client";
import React from "react";
import { School, Utensils, Spade, Bike, Cake, Dumbbell } from "../Components/lucide-react";
import { mockServices } from "../data/mockData";

export default function Servise() {
  const serviceIcons = {
    "srv-1": <School size={28} />,
    "srv-2": <Utensils size={28} />,
    "srv-3": <Spade size={28} />,
    "srv-4": <Bike size={28} />,
    "srv-5": <Cake size={28} />,
    "srv-6": <Dumbbell size={28} />,
  };

  return (
    <section id="services" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Background glowing gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-amber-500/10 blur-[140px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-widest mb-3">
            Elite Hospitality
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Explore Our World-Class <span className="text-amber-400">Services</span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-gray-400">
            From Michelin-grade dining to restorative therapeutic wellness, experience unmatched care at every touchpoint.
          </p>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockServices.map((srv) => (
            <div
              key={srv.id}
              className="group relative bg-slate-800/60 border border-slate-700/80 hover:border-amber-500/50 rounded-2xl p-7 transition-all duration-300 hover:-translate-y-1.5 shadow-lg overflow-hidden flex flex-col justify-between"
            >
              {/* Subtle hover gradient background */}
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-5 group-hover:scale-110 group-hover:bg-amber-500 group-hover:text-slate-950 transition-all duration-300 shadow-md">
                  {serviceIcons[srv.id]}
                </div>

                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest">
                  {srv.category}
                </span>

                <h3 className="text-xl font-bold text-white mt-1 mb-2 group-hover:text-amber-300 transition-colors">
                  {srv.title}
                </h3>

                <p className="text-sm text-gray-400 leading-relaxed">
                  {srv.description}
                </p>
              </div>

              <div className="pt-5 mt-4 border-t border-slate-700/60 relative z-10 flex items-center justify-between text-xs font-semibold text-gray-400 group-hover:text-amber-400">
                <span>Included with stay</span>
                <span className="text-amber-400 group-hover:translate-x-1 transition-transform">Learn more →</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
